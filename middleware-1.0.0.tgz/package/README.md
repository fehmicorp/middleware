# Next Proxy Middleware

A lightweight **Next.js middleware proxy layer** for secure API routing using Redis-backed route configuration.

This middleware dynamically maps requests to backend services based on keys stored in Redis.

---

# Features

- Redis based dynamic route mapping
- JWT authentication validation
- Cookie-based authentication support
- Query parameter routing
- Function based routing via `fnKey`
- Header-based authentication injection
- Support for all HTTP methods

Supported methods:

GET  
POST  
PUT  
PATCH  
DELETE  
WebSocket

---

# Architecture

Client Request
↓
Next.js Middleware
↓
Redis Route Lookup
↓
Header Injection
↓
Next.js Route Handler / Backend Service

---

# Installation

```bash
npm install @fehmicorp/next-proxy-middleware